package com.example.servertask

interface FavoriteTaskCallback {
    fun onFavoriteTaskCompleted(result: String)
}
